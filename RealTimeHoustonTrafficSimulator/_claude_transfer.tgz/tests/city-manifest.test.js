import test from 'node:test';
import assert from 'node:assert/strict';
import { houstonManifest } from '../src/cities/houston/manifest.js';
import { isCityManifest, CITY_IDS } from '../src/cities/types.js';
import { transtarAdapter } from '../src/feeds/transtar.js';
import { preferredBoardAirport, resolveBoardAirportCodes } from '../src/cities/airport-set.js';

test('houston manifest', async (t) => {
  await t.test('passes shape check', () => {
    assert.equal(isCityManifest(houstonManifest), true);
  });
  await t.test('has Houston origin downtown', () => {
    assert.equal(houstonManifest.id, 'houston');
    assert.ok(Math.abs(houstonManifest.origin.lat - 29.7604) < 0.001);
    assert.equal(houstonManifest.origin.unitsPerMile, 1609.344);
  });
  await t.test('lists in CITY_IDS', () => {
    assert.ok(CITY_IDS.includes('houston'));
  });
});

test('transtar adapter', async (t) => {
  await t.test('supports houston only', () => {
    assert.equal(transtarAdapter.supports(houstonManifest), true);
    assert.equal(transtarAdapter.supports({ id: 'austin', feeds: { primaryTraffic: 'tomtom' } }), false);
  });
  await t.test('refresh returns a snapshot shape', async () => {
    const fakeFetch = async () => ({
      ok: true,
      status: 200,
      text: async () => '<?xml version="1.0"?><rss><channel></channel></rss>',
      headers: { get: () => 'application/xml' },
    });
    const snap = await transtarAdapter.refresh(houstonManifest, {
      fetchWithTimeout: fakeFetch,
    });
    assert.ok(snap.at > 0);
    assert.ok(snap.flows instanceof Map);
    assert.ok(Array.isArray(snap.incidents));
  });
});

test('metro airport selection prefers the active city airport list', () => {
  const dallasCity = { id: 'dallas', airportCodes: ['DFW', 'DAL', 'ADS'] };
  const dallasPack = { boardApts: ['DFW', 'DAL', 'ADS'] };
  assert.deepEqual(resolveBoardAirportCodes(dallasCity, dallasPack, ['IAH', 'HOU']), ['DFW', 'DAL', 'ADS']);
  assert.equal(preferredBoardAirport(dallasCity, dallasPack, ['IAH', 'HOU']), 'DFW');
  assert.equal(preferredBoardAirport({ id: 'austin', airportCodes: ['AUS', 'EDC'] }, { boardApts: ['AUS', 'EDC'] }, ['IAH']), 'AUS');
});
